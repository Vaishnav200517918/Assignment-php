<?php

class database
{
    private $username = "Vaishnav200517918";
    private $database = "Vaishnav200517918";
    private $servername   = "172.31.22.43";
    private $password = "gEerDBOc6H";
    public $con;


    public function __construct(){
        $this->con = new mysqli($this->servername, $this->username,$this->password,$this->database);
        if(mysqli_connect_error()){
            trigger_error("Connection failed :" . mysqli_connect_error());
        }else{
            return $this->con;
        }
    }

    public function addData($post){
        $name = $this->con->real_escape_string($_POST['name']);
        $age = $this->con->real_escape_string($_POST['age']);
        $department = $this->con->real_escape_string($_POST['department']);
        $query="INSERT INTO employeet (nname,age,department) VALUES('$name','$age','$department')";
        $sql = $this->con->query($query);

    }

    public function displayData(){
        $query = "SELECT * FROM employeet";
        $result = $this->con->query($query);
        if ($result->num_rows > 0) {
            $data = array();
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
            return $data;
        }
    }

}