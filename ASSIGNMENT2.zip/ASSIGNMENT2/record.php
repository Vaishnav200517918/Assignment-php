<?php

// Include database file
include 'database.php';

$employeetObj = new database();

// Insert Record in customer table
if(isset($_POST['submit'])) {
    $employeetObj->addData($_POST);
}

?>






<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="This is the introduction to using PHP" />
    <meta name="robots" content="noindex, nofollow" />
    <title>Records</title>
    <link rel="stylesheet" href="css/style.css" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
      crossorigin="anonymous"
    />
  </head>
  <body>
    <header>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            <img
              src="https://media.istockphoto.com/vectors/letter-logo-vector-e-logo-beautiful-logotype-design-for-luxury-vector-id1301871712?b=1&k=20&m=1301871712&s=612x612&w=0&h=OFfEGgP1yLYG7DkJCHakWB0UvlGUNKKRfJP-S4CMhRc="
              alt="Logo"
              width="30"
              height="24"
              class="d-inline-block align-text-top"
            />
            EMPLO
          </a>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="#">Records</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">About</a>
              </li>
            </ul>
            <form class="d-flex" role="search">
              <input
                class="form-control me-2"
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
              <button class="btn btn-outline-success" type="submit">
                Search
              </button>
            </form>
          </div>
        </div>
      </nav>
    </header>
    <main>
      <div class="row">
        <div class="col-md-7">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Id</th>
                <th scope="col">Name</th>
                <th scope="col">Age</th>
                <th scope="col">Department</th>
              </tr>
            </thead>
            <tbody class="table-group-divider">
            <?php
            $employeet = $employeetObj->displayData();
            foreach ($employeet as $employee) {
                ?>
                <tr>
                    <td><?php echo $employee['id'] ?></td>
                    <td><?php echo $employee['nname'] ?></td>
                    <td><?php echo $employee['age'] ?></td>
                    <td><?php echo $employee['department'] ?></td>
                </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="row">
        <div class="col-md-7">
          <div class="forms">
            <form action="record.php" method="POST">
              <div class="form-group">
                <label for="name">Name:</label>
                <input
                  type="text"
                  class="form-control"
                  name="name"
                  placeholder="Enter name"
                  required=""
                />
              </div>
              <div class="form-group">
                <label for="age">Age</label>
                <input
                  type="text"
                  class="form-control"
                  name="age"
                  placeholder="Enter age"
                  required=""
                />
              </div>
              <div class="form-group">
                <label for="department">Department:</label>
                <input
                  type="text"
                  class="form-control"
                  name="department"
                  placeholder="Enter department"
                  required=""
                />
              </div>
              <input
                type="submit"
                name="submit"
                class="submit-btn"
                style="float: right"
                value="Submit"
              />
            </form>
          </div>
        </div>
      </div>
    </main>
    <footer>
        <h2 class="footer-head">Emplo</h2>
        <p class="footer-p">
            Contact us : Emplo@gmail.com
        </p>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
      integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"
      integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
