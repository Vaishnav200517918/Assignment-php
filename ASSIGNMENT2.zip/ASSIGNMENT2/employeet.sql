CREATE TABLE employeet (
    id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nname varchar(100) NOT NULL,
    age varchar(100) NOT NULL,
    department varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

